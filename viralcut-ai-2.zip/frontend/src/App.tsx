import { useEffect, useMemo, useRef, useState } from 'react';
import { Activity, ArrowUpRight, Check, ChevronDown, Clapperboard, Clock3, Copy, Download, FileVideo, Film, Globe2, Loader2, Play, Scissors, Settings2, Sparkles, Subtitles, UploadCloud, WandSparkles, Youtube } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';
type Clip = {id:string; title:string; score:number; start:number; end:number; reason:string; hashtags:string[]; video_url:string; style?:string; position?:string};
type Job = {job_id:string;status:string;progress:number;step:string;error?:string|null;clips:Clip[];source_duration?:number};
const durations = [15,20,30];

function App(){
  const [mode,setMode]=useState<'youtube'|'upload'>('youtube');
  const [url,setUrl]=useState('');
  const [file,setFile]=useState<File|null>(null);
  const [duration,setDuration]=useState(20);
  const [job,setJob]=useState<Job|null>(null);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [editing,setEditing]=useState<string|null>(null);
  const [titleDraft,setTitleDraft]=useState('');
  const [styleClip,setStyleClip]=useState<string|null>(null);
  const [style,setStyle]=useState('bold');
  const [position,setPosition]=useState('center');
  const [rtl,setRtl]=useState(false);
  const inputRef=useRef<HTMLInputElement>(null);

  useEffect(()=>{ if(!job || ['completed','failed'].includes(job.status)) return; const timer=setInterval(async()=>{try{const r=await fetch(`${API}/api/jobs/${job.job_id}`);if(r.ok){const data=await r.json();setJob(data);if(['completed','failed'].includes(data.status))setBusy(false);}}catch{}},1800);return()=>clearInterval(timer);},[job?.job_id,job?.status]);

  const create=async()=>{
    setError('');
    if(mode==='youtube' && !url.trim()){setError('Paste a YouTube URL first.');return;}
    if(mode==='upload' && !file){setError('Choose a video file first.');return;}
    setBusy(true);setJob(null);
    try{
      const form=new FormData();form.append('duration',String(duration));
      let endpoint='';
      if(mode==='youtube'){form.append('url',url.trim());endpoint='/api/jobs/youtube';}
      else{form.append('file',file!);endpoint='/api/jobs/upload';}
      const res=await fetch(`${API}${endpoint}`,{method:'POST',body:form});
      const data=await res.json();if(!res.ok)throw new Error(data.detail||'Could not start processing.');
      setJob({job_id:data.job_id,status:'queued',progress:0,step:'Queued',clips:[]});
    }catch(e:any){setError(e.message||'Something went wrong.');setBusy(false);}
  };
  const saveTitle=async(clip:Clip)=>{
    try{const r=await fetch(`${API}/api/jobs/${job!.job_id}/clips/${clip.id}/title`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:titleDraft})});if(!r.ok)throw new Error('Could not save title');setJob(j=>j?{...j,clips:j.clips.map(c=>c.id===clip.id?{...c,title:titleDraft}:c)}:j);setEditing(null);}catch(e:any){setError(e.message);}
  };
  const saveStyle=async(clip:Clip)=>{
    try{const r=await fetch(`${API}/api/jobs/${job!.job_id}/clips/${clip.id}/style`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({preset:style,position})});const data=await r.json();if(!r.ok)throw new Error(data.detail||'Could not update style');setJob(j=>j?{...j,clips:j.clips.map(c=>c.id===clip.id?data.clip:c)}:j);setStyleClip(null);}catch(e:any){setError(e.message);}
  };
  const copyClip=(clip:Clip)=>navigator.clipboard.writeText(`${clip.title}\n${clip.hashtags.map(h=>'#'+h).join(' ')}`);
  const mediaUrl=(path:string)=>path.startsWith('http')?path:`${API}${path}`;
  const isRunning=busy && job && !['completed','failed'].includes(job.status);
  const stages=['Downloading video','Preparing video','Extracting audio','Transcribing speech with word timestamps','Analyzing viral hooks with Gemini'];
  return <div className="min-h-screen bg-ink text-white" dir={rtl?'rtl':'ltr'}>
    <header className="border-b border-line/80 bg-[#0c0c14]/90 backdrop-blur sticky top-0 z-20">
      <div className="max-w-7xl mx-auto px-5 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-violet-500/15 border border-violet-400/30 flex items-center justify-center"><Scissors className="text-violet-300" size={19}/></div><div><div className="font-extrabold tracking-tight text-lg">ViralCut <span className="text-violet-300">AI</span></div><div className="text-[10px] text-slate-500 -mt-1 tracking-[.18em] uppercase">Short-form studio</div></div></div>
        <div className="flex items-center gap-2"><button onClick={()=>setRtl(!rtl)} className="ghost"><Globe2 size={15}/>{rtl?'العربية':'EN / AR'}</button><div className="hidden sm:flex items-center gap-2 text-xs text-slate-400 px-3 py-2 rounded-full border border-line"><span className="w-2 h-2 rounded-full bg-emerald-400"/> AI engine ready</div></div>
      </div>
    </header>
    <main className="max-w-7xl mx-auto px-5 py-10">
      <section className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-violet-400/20 bg-violet-400/5 text-violet-200 text-xs mb-5"><Sparkles size={13}/> AI-powered clip discovery</div>
        <h1 className="text-4xl sm:text-6xl font-black tracking-tight leading-[1.06]">One long video.<br/><span className="gradient-text">Ten viral moments.</span></h1>
        <p className="text-slate-400 mt-5 text-base sm:text-lg leading-relaxed">Turn podcasts, interviews and long videos into scroll-stopping vertical clips — with smart framing and animated captions.</p>
      </section>

      <section className="max-w-4xl mx-auto glass rounded-3xl p-5 sm:p-7 shadow-2xl shadow-black/20">
        <div className="flex items-center justify-between mb-5"><div><h2 className="font-bold text-lg">Create your clips</h2><p className="text-slate-500 text-sm mt-1">Start with a YouTube link or upload a video file.</p></div><div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center"><WandSparkles className="text-violet-300"/></div></div>
        <div className="flex gap-2 p-1 rounded-xl bg-black/25 w-fit mb-5">
          <button className={`tab ${mode==='youtube'?'tab-active':''}`} onClick={()=>setMode('youtube')}><Youtube size={16}/> YouTube URL</button>
          <button className={`tab ${mode==='upload'?'tab-active':''}`} onClick={()=>setMode('upload')}><UploadCloud size={16}/> Upload file</button>
        </div>
        {mode==='youtube'?<div className="relative"><Youtube className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={19}/><input value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className="field pl-12"/></div>:
          <div onClick={()=>inputRef.current?.click()} className="upload-zone cursor-pointer rounded-2xl p-8 text-center"><input ref={inputRef} type="file" accept=".mp4,.mov,.m4v,.webm,video/mp4,video/quicktime" className="hidden" onChange={e=>setFile(e.target.files?.[0]||null)}/><FileVideo size={30} className="mx-auto text-violet-300 mb-3"/><p className="font-semibold">{file?file.name:'Drop your video here or browse files'}</p><p className="text-xs text-slate-500 mt-2">MP4, MOV, M4V or WEBM · Up to 2 GB by default</p></div>}
        <div className="mt-6"><div className="flex items-center justify-between mb-3"><label className="text-sm font-semibold">Target clip duration</label><span className="text-xs text-slate-500">Choose your format</span></div><div className="grid grid-cols-3 gap-3">{durations.map(d=><button key={d} onClick={()=>setDuration(d)} className={`duration ${duration===d?'duration-active':''}`}><Clock3 size={16}/><span className="text-lg font-bold">{d}s</span><span className="text-[11px] text-slate-500">per clip</span></button>)}</div></div>
        {error&&<div className="mt-4 text-sm text-rose-300 bg-rose-400/10 border border-rose-400/20 rounded-xl p-3">{error}</div>}
        <button onClick={create} disabled={busy} className="primary-btn w-full mt-6">{busy?<><Loader2 className="animate-spin" size={18}/> Processing your video…</>:<><Sparkles size={18}/> Find my 10 viral clips <ArrowUpRight size={17}/></>}</button>
        <p className="text-center text-[11px] text-slate-600 mt-3">Only upload videos you own or are authorized to process.</p>
      </section>

      {isRunning&&<section className="max-w-4xl mx-auto mt-7 glass rounded-2xl p-5"><div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2 font-semibold"><Loader2 size={17} className="animate-spin text-violet-300"/>{job?.step||'Working…'}</div><span className="text-sm text-violet-200 font-bold">{job?.progress||0}%</span></div><div className="h-2 rounded-full bg-white/5 overflow-hidden"><div className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-400 transition-all duration-700" style={{width:`${job?.progress||0}%`}}/></div><div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-4">{['Download','Transcribe','Analyze','Crop','Captions'].map((s,i)=><div className="text-[11px] text-slate-500 flex items-center gap-1.5" key={s}><span className={`w-1.5 h-1.5 rounded-full ${(job?.progress||0)>[5,28,52,56,90][i]?'bg-emerald-400':'bg-slate-700'}`}/>{s}</div>)}</div></section>}
      {job?.status==='failed'&&<div className="max-w-4xl mx-auto mt-6 p-4 rounded-xl border border-rose-500/20 bg-rose-500/10 text-rose-200 text-sm">Processing failed: {job.error||'Unknown error'}</div>}

      {job?.status==='completed'&&<section className="mt-12"><div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6"><div><div className="text-xs text-violet-300 font-bold tracking-widest uppercase mb-2">Your content is ready</div><h2 className="text-3xl font-black">Your viral moments <span className="text-slate-500 text-xl">({job.clips.length})</span></h2><p className="text-slate-500 text-sm mt-1">Edit titles, customize captions and download your vertical clips.</p></div><div className="flex items-center gap-2 text-xs text-slate-400"><span className="w-2 h-2 rounded-full bg-emerald-400"/> Processing complete</div></div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">{job.clips.map((clip,i)=><article key={clip.id} className="clip-card overflow-hidden rounded-2xl border border-line bg-panel">
          <div className="video-wrap relative"><video src={mediaUrl(clip.video_url)} controls playsInline preload="metadata" className="w-full aspect-[9/16] object-cover bg-black"/><div className="absolute top-3 left-3 score"><Sparkles size={11}/>{clip.score} VIRAL</div><div className="absolute top-3 right-3 text-[10px] px-2 py-1 rounded-full bg-black/60 border border-white/10">CLIP {String(i+1).padStart(2,'0')}</div></div>
          <div className="p-4"><div className="flex items-start justify-between gap-2"><h3 className="font-bold leading-snug text-sm">{clip.title}</h3><button title="Edit title" onClick={()=>{setEditing(clip.id);setTitleDraft(clip.title)}} className="icon-btn">✎</button></div><p className="text-xs text-slate-500 mt-2 line-clamp-3">{clip.reason}</p><div className="text-[11px] text-slate-600 mt-3 flex items-center gap-1"><Clock3 size={12}/>{clip.start.toFixed(1)}s – {clip.end.toFixed(1)}s</div>
            <div className="grid grid-cols-3 gap-2 mt-4"><a href={mediaUrl(clip.video_url)} download className="action-btn"><Download size={14}/> Save</a><button onClick={()=>copyClip(clip)} className="action-btn"><Copy size={14}/> Copy</button><button onClick={()=>{setStyleClip(clip.id);setStyle(clip.style||'bold');setPosition(clip.position||'center')}} className="action-btn"><Settings2 size={14}/> Style</button></div>
          </div></article>)}</div>
      </section>}
      <section className="grid sm:grid-cols-3 gap-4 max-w-4xl mx-auto mt-14">
        {[{icon:<Activity/>,title:'Find the hook',desc:'Gemini scores moments by emotional impact, clarity and shareability.'},{icon:<Subtitles/>,title:'Captions that pop',desc:'Word-timed captions with Arabic and English subtitle rendering.'},{icon:<Film/>,title:'Vertical-ready',desc:'9:16 exports with face-aware framing and social-ready MP4 output.'}].map(x=><div className="feature" key={x.title}><div className="text-violet-300 mb-3">{x.icon}</div><h3 className="font-bold text-sm">{x.title}</h3><p className="text-xs text-slate-500 mt-2 leading-relaxed">{x.desc}</p></div>)}
      </section>
    </main>
    <footer className="border-t border-line mt-16 py-7 text-center text-xs text-slate-600">ViralCut AI · Built for creators who make every second count.</footer>

    {editing&&<div className="modal-backdrop" onClick={()=>setEditing(null)}><div className="modal" onClick={e=>e.stopPropagation()}><h3 className="font-bold text-lg mb-4">Edit clip title</h3><input className="field" value={titleDraft} onChange={e=>setTitleDraft(e.target.value)}/><div className="flex gap-2 mt-5"><button className="secondary-btn flex-1" onClick={()=>setEditing(null)}>Cancel</button><button className="primary-btn flex-1" onClick={()=>{const c=job!.clips.find(x=>x.id===editing);if(c)saveTitle(c)}}><Check size={16}/> Save title</button></div></div></div>}
    {styleClip&&<div className="modal-backdrop" onClick={()=>setStyleClip(null)}><div className="modal" onClick={e=>e.stopPropagation()}><h3 className="font-bold text-lg mb-1">Caption appearance</h3><p className="text-xs text-slate-500 mb-5">Re-render this clip with a new subtitle preset.</p><label className="text-xs text-slate-400">Style preset</label><div className="grid grid-cols-3 gap-2 mt-2">{['bold','minimal','neon'].map(s=><button onClick={()=>setStyle(s)} className={`duration ${style===s?'duration-active':''}`} key={s}>{s}</button>)}</div><label className="text-xs text-slate-400 block mt-5">Caption position</label><select className="field mt-2" value={position} onChange={e=>setPosition(e.target.value)}><option value="top">Top</option><option value="center">Center</option><option value="bottom">Bottom</option></select><div className="flex gap-2 mt-5"><button className="secondary-btn flex-1" onClick={()=>setStyleClip(null)}>Cancel</button><button className="primary-btn flex-1" onClick={()=>{const c=job!.clips.find(x=>x.id===styleClip);if(c)saveStyle(c)}}><WandSparkles size={16}/> Apply style</button></div></div></div>}
  </div>
}
export default App;
