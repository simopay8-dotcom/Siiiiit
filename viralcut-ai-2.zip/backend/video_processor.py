import os
import re
import json
import math
import subprocess
import uuid
from pathlib import Path
from typing import Callable
import cv2
from dotenv import load_dotenv
from faster_whisper import WhisperModel
from google import genai
from google.genai import types

load_dotenv()
WHISPER_MODEL_NAME = os.getenv("WHISPER_MODEL", "small")
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
WHISPER_COMPUTE = os.getenv("WHISPER_COMPUTE_TYPE", "int8")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
_whisper = None

def run(cmd):
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(map(str, cmd))}\n{result.stderr[-3000:]}")
    return result.stdout.strip()

def probe_duration(path: Path) -> float:
    raw = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    duration = float(raw)
    if not math.isfinite(duration) or duration <= 0:
        raise RuntimeError("The uploaded video has an invalid duration.")
    return duration

def download_youtube_video(url: str, target: Path):
    target.parent.mkdir(parents=True, exist_ok=True)
    run(["yt-dlp", "--no-playlist", "--format", "bv*[height<=1080]+ba/b[height<=1080]",
         "--merge-output-format", "mp4", "--output", str(target), url])
    if not target.exists():
        candidates = list(target.parent.glob(target.stem + ".*"))
        if candidates:
            candidates[0].replace(target)
    if not target.exists():
        raise RuntimeError("YouTube download did not produce a video file.")

def extract_audio(video: Path, audio: Path):
    run(["ffmpeg", "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
         "-c:a", "pcm_s16le", str(audio)])

def transcribe(audio: Path):
    global _whisper
    if _whisper is None:
        _whisper = WhisperModel(WHISPER_MODEL_NAME, device=WHISPER_DEVICE,
                                compute_type=WHISPER_COMPUTE)
    segments, info = _whisper.transcribe(str(audio), word_timestamps=True,
                                         vad_filter=True, beam_size=5)
    words = []
    transcript_segments = []
    for seg in segments:
        text = (seg.text or "").strip()
        transcript_segments.append({"start": float(seg.start), "end": float(seg.end), "text": text})
        for word in (seg.words or []):
            token = (word.word or "").strip()
            if token:
                words.append({"word": token, "start": float(word.start), "end": float(word.end)})
    if not transcript_segments:
        raise RuntimeError("No speech was detected in this video.")
    return {"language": info.language, "segments": transcript_segments, "words": words}

def select_viral_moments(transcript, duration: int, video_duration: float):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to backend/.env.")
    client = genai.Client(api_key=api_key)
    compact = "\n".join(
        f'[{s["start"]:.2f}-{s["end"]:.2f}] {s["text"]}'
        for s in transcript["segments"]
    )
    schema = {
        "type": "OBJECT",
        "properties": {
            "clips": {
                "type": "ARRAY",
                "minItems": 10,
                "maxItems": 10,
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "title": {"type": "STRING"},
                        "score": {"type": "INTEGER"},
                        "start": {"type": "NUMBER"},
                        "end": {"type": "NUMBER"},
                        "reason": {"type": "STRING"},
                        "hashtags": {"type": "ARRAY", "items": {"type": "STRING"}}
                    },
                    "required": ["title", "score", "start", "end", "reason", "hashtags"]
                }
            }
        },
        "required": ["clips"]
    }
    prompt = f"""
You are an expert short-form video editor and audience-retention analyst.
Select exactly 10 distinct high-potential moments from this transcript.
Target clip length: {duration} seconds. Video length: {video_duration:.2f} seconds.
Each clip must be between {max(8, duration-2)} and {duration+2} seconds, stay within
the video, and overlap as little as practical. Prefer strong hooks, surprising claims,
emotional peaks, humor, useful insights, conflict, clear standalone context, and
high-curiosity moments. Do not invent events or claims. Titles should be catchy and
accurate, ideally concise. Score 1-100 based on hook strength, emotional impact,
clarity, and shareability. Provide a brief grounded reason and 3-5 relevant hashtags.
The timestamps must align with the transcript. Return JSON matching the schema.

TRANSCRIPT:
{compact[:90000]}
"""
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=schema,
            temperature=0.25
        )
    )
    try:
        data = json.loads(response.text)
        clips = data["clips"]
    except Exception as exc:
        raise RuntimeError(f"Gemini returned invalid clip data: {exc}")
    valid = []
    for item in clips:
        start = max(0.0, float(item["start"]))
        end = min(video_duration, float(item["end"]))
        if end <= start or end - start < 6:
            continue
        if end - start > duration + 4:
            end = start + duration
        valid.append({
            "id": str(uuid.uuid4())[:8],
            "title": str(item["title"])[:160],
            "score": max(1, min(100, int(item["score"]))),
            "start": start, "end": end,
            "reason": str(item["reason"])[:500],
            "hashtags": [str(x).strip().lstrip("#") for x in item.get("hashtags", [])[:6]],
        })
    if len(valid) < 1:
        raise RuntimeError("Gemini did not identify any valid moments. Try another video.")
    # Rank by score, then ensure no duplicate time windows.
    valid.sort(key=lambda x: x["score"], reverse=True)
    chosen = []
    for clip in valid:
        if all(min(clip["end"], c["end"]) - max(clip["start"], c["start"]) < duration * 0.55
               for c in chosen):
            chosen.append(clip)
        if len(chosen) == 10:
            break
    if not chosen:
        raise RuntimeError("No distinct clip moments were returned.")
    return chosen

def detect_face_center(video: Path, start: float, end: float):
    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        return 0.5
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    frame_count = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    duration = frame_count / fps if frame_count else end
    sample_times = [start + (end-start)*p for p in (0.2, 0.5, 0.8)]
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(cascade_path)
    centers = []
    for sec in sample_times:
        cap.set(cv2.CAP_PROP_POS_MSEC, max(0, sec) * 1000)
        ok, frame = cap.read()
        if not ok:
            continue
        h, w = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
        if len(faces):
            x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
            centers.append((x + fw / 2) / w)
    cap.release()
    return sum(centers) / len(centers) if centers else 0.5

def ass_time(seconds: float):
    cs = max(0, int(round(seconds * 100)))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, centi = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{centi:02d}"

def ass_escape(text: str):
    return text.replace("\\", r"\\").replace("{", r"\{").replace("}", r"\}").replace("\n", " ")

def build_ass(words, clip_start, clip_end, out_ass, preset="bold", position="center"):
    styles = {
        "bold": ("Arial", 68, "&H0000FFFF", "&H00FFFFFF", 1, 4),
        "minimal": ("Arial", 54, "&H00FFFFFF", "&H00000000", 1, 3),
        "neon": ("Arial", 64, "&H0000D7FF", "&H00FFFFFF", 1, 4)
    }
    font, size, primary, outline, border, shadow = styles.get(preset, styles["bold"])
    alignment = {"bottom": 2, "center": 5, "top": 8}.get(position, 5)
    margin_v = 150 if position == "bottom" else (180 if position == "top" else 80)
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{font},{size},{primary},&H000000FF,{outline},&H99000000,-1,0,0,0,100,100,0,0,1,{border},{shadow},{alignment},70,70,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events = []
    clip_words = [w for w in words if w["end"] >= clip_start and w["start"] <= clip_end]
    # Group up to four words per event for readable, punchy captions.
    for i in range(0, len(clip_words), 4):
        group = clip_words[i:i+4]
        if not group:
            continue
        start = max(clip_start, group[0]["start"])
        end = min(clip_end, group[-1]["end"] + 0.12)
        if end <= start:
            continue
        phrase = " ".join(ass_escape(w["word"]) for w in group)
        # Pop-in scale animation on each phrase.
        animated = r"{\fad(70,80)\fscx92\fscy92\t(0,100,\fscx108\fscy108)\t(100,170,\fscx100\fscy100)}" + phrase
        events.append(f"Dialogue: 0,{ass_time(start-clip_start)},{ass_time(end-clip_start)},Default,,0,0,0,,{animated}")
    out_ass.write_text(header + "\n".join(events) + "\n", encoding="utf-8-sig")

def render_clip(video: Path, clip: dict, words: list, out_path: Path, preset="bold", position="center"):
    start, end = clip["start"], clip["end"]
    center = detect_face_center(video, start, end)
    # Fit a 9:16 crop. The crop expression keeps a detected face near the center.
    ass_path = out_path.with_suffix(".ass")
    build_ass(words, start, end, ass_path, preset, position)
    escaped_ass = str(ass_path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
    vf = (
        "scale=1080:1920:force_original_aspect_ratio=increase,"
        f"crop=ih*9/16:ih:x='max(0,min(iw-ih*9/16,(iw-ih*9/16)*{center:.5f}))':y=0,"
        f"setsar=1,subtitles='{escaped_ass}'"
    )
    run(["ffmpeg", "-y", "-ss", f"{start:.3f}", "-i", str(video), "-t",
         f"{end-start:.3f}", "-vf", vf, "-c:v", "libx264", "-preset", "veryfast",
         "-crf", "21", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
         "-pix_fmt", "yuv420p", str(out_path)])
    ass_path.unlink(missing_ok=True)
    return out_path

def render_single_clip(clip, preset, position):
    video = Path(clip["source_path"])
    out_dir = Path(clip["output_path"]).parent
    out = out_dir / f"{clip['id']}_{preset}_{position}.mp4"
    render_clip(video, clip, clip["words"], out, preset, position)
    clip["output_path"] = str(out)
    return out

def process_video(source_path: str, job_id: str, target_duration: int, output_dir: Path,
                  progress: Callable[[int, str], None]):
    video = Path(source_path)
    if not video.exists() or video.stat().st_size == 0:
        raise RuntimeError("The source video is missing or empty.")
    duration = probe_duration(video)
    if duration < 20:
        raise RuntimeError("Please provide a video longer than 20 seconds.")
    work = output_dir / job_id
    work.mkdir(parents=True, exist_ok=True)
    audio = work / "audio.wav"
    progress(12, "Extracting audio")
    extract_audio(video, audio)
    progress(28, "Transcribing speech with word timestamps")
    transcript = transcribe(audio)
    progress(52, "Analyzing viral hooks with Gemini")
    clips = select_viral_moments(transcript, target_duration, duration)
    results = []
    for idx, clip in enumerate(clips):
        progress(55 + int(42 * idx / max(1, len(clips))), f"Rendering Reel {idx+1} of {len(clips)}")
        output = work / f"reel_{idx+1:02d}.mp4"
        render_clip(video, clip, transcript["words"], output)
        results.append({
            **clip,
            "video_url": f"/media/{output.name}" if False else f"/media/{job_id}/{output.name}",
            "output_path": str(output),
            "source_path": str(video),
            "words": transcript["words"],
            "style": "bold",
            "position": "center"
        })
    # media route accepts nested job paths via separate route in main.
    return {"clips": results, "source_duration": duration}
