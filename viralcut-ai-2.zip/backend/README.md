# Backend
The FastAPI service exposes:
- `POST /api/jobs/upload` multipart fields `file`, `duration`
- `POST /api/jobs/youtube` multipart fields `url`, `duration`
- `GET /api/jobs/{job_id}`
- `PATCH /api/jobs/{job_id}/clips/{clip_id}/title`
- `PATCH /api/jobs/{job_id}/clips/{clip_id}/style`
- `GET /media/{job_id}/{filename}`

Run `uvicorn main:app --reload --port 8000`.
