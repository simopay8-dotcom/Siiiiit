import os
import uuid
import shutil
import asyncio
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from video_processor import process_video, download_youtube_video, render_single_clip

load_dotenv()
BASE = Path(__file__).resolve().parent
STORAGE = Path(os.getenv("STORAGE_DIR", str(BASE / "storage"))).resolve()
UPLOADS = STORAGE / "uploads"
OUTPUTS = STORAGE / "outputs"
for p in (UPLOADS, OUTPUTS):
    p.mkdir(parents=True, exist_ok=True)

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "2048"))
jobs = {}

app = FastAPI(title="ViralCut AI API", version="1.0.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware, allow_origins=origins, allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"], allow_headers=["*"]
)

class CreateJobResponse(BaseModel):
    job_id: str
    status: str

class TitleUpdate(BaseModel):
    title: str = Field(min_length=1, max_length=160)

class StyleUpdate(BaseModel):
    preset: str = Field(pattern="^(bold|minimal|neon)$")
    position: str = Field(default="center", pattern="^(top|center|bottom)$")

def update_job(job_id, **kwargs):
    if job_id in jobs:
        jobs[job_id].update(kwargs)

async def run_job(job_id: str, source_path: str, duration: int):
    try:
        update_job(job_id, status="processing", progress=5, step="Preparing video")
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, lambda: process_video(source_path, job_id, duration, OUTPUTS,
                                        lambda pct, step: update_job(job_id, progress=pct, step=step))
        )
        update_job(job_id, status="completed", progress=100, step="Ready", clips=result["clips"],
                   source_duration=result["source_duration"])
    except Exception as exc:
        update_job(job_id, status="failed", error=str(exc), step="Processing failed")

async def create_job(source_path: str, duration: int):
    job_id = str(uuid.uuid4())
    jobs[job_id] = {
        "job_id": job_id, "status": "queued", "progress": 0, "step": "Queued",
        "duration": duration, "clips": [], "error": None
    }
    asyncio.create_task(run_job(job_id, source_path, duration))
    return job_id

@app.get("/api/health")
async def health():
    return {"ok": True, "service": "ViralCut AI"}

@app.post("/api/jobs/upload", response_model=CreateJobResponse)
async def upload_video(file: UploadFile = File(...), duration: int = Form(...)):
    if duration not in (15, 20, 30):
        raise HTTPException(400, "Duration must be 15, 20, or 30 seconds.")
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in (".mp4", ".mov", ".m4v", ".webm"):
        raise HTTPException(400, "Supported formats: MP4, MOV, M4V, WEBM.")
    job_id = str(uuid.uuid4())
    target = UPLOADS / f"{job_id}{suffix}"
    size = 0
    try:
        with target.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    raise HTTPException(413, f"Upload exceeds {MAX_UPLOAD_MB} MB.")
                out.write(chunk)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    jobs[job_id] = {"job_id": job_id, "status": "queued", "progress": 0,
                    "step": "Queued", "duration": duration, "clips": [], "error": None}
    asyncio.create_task(run_job(job_id, str(target), duration))
    return CreateJobResponse(job_id=job_id, status="queued")

@app.post("/api/jobs/youtube", response_model=CreateJobResponse)
async def youtube_job(url: str = Form(...), duration: int = Form(...)):
    if duration not in (15, 20, 30):
        raise HTTPException(400, "Duration must be 15, 20, or 30 seconds.")
    if not url.startswith(("https://www.youtube.com/", "https://youtube.com/",
                           "https://youtu.be/", "http://www.youtube.com/")):
        raise HTTPException(400, "Please provide a valid YouTube URL.")
    job_id = str(uuid.uuid4())
    target = UPLOADS / f"{job_id}.mp4"
    jobs[job_id] = {"job_id": job_id, "status": "queued", "progress": 0,
                    "step": "Waiting to download", "duration": duration, "clips": [], "error": None}
    async def download_then_process():
        try:
            update_job(job_id, status="processing", progress=2, step="Downloading video")
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, lambda: download_youtube_video(url, target))
            await run_job(job_id, str(target), duration)
        except Exception as exc:
            update_job(job_id, status="failed", error=str(exc), step="Download failed")
    asyncio.create_task(download_then_process())
    return CreateJobResponse(job_id=job_id, status="queued")

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found.")
    return job

@app.patch("/api/jobs/{job_id}/clips/{clip_id}/title")
async def update_title(job_id: str, clip_id: str, body: TitleUpdate):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found.")
    for clip in job.get("clips", []):
        if clip["id"] == clip_id:
            clip["title"] = body.title
            return {"ok": True, "clip": clip}
    raise HTTPException(404, "Clip not found.")

@app.patch("/api/jobs/{job_id}/clips/{clip_id}/style")
async def update_style(job_id: str, clip_id: str, body: StyleUpdate):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found.")
    clip = next((c for c in job.get("clips", []) if c["id"] == clip_id), None)
    if not clip:
        raise HTTPException(404, "Clip not found.")
    try:
        loop = asyncio.get_running_loop()
        new_path = await loop.run_in_executor(
            None, lambda: render_single_clip(clip, body.preset, body.position)
        )
        clip["video_url"] = f"/media/{Path(new_path).name}"
        clip["style"] = body.preset
        clip["position"] = body.position
        return {"ok": True, "clip": clip}
    except Exception as exc:
        raise HTTPException(500, f"Could not re-render clip: {exc}")

@app.get("/media/{job_id}/{filename}")
async def media(job_id: str, filename: str):
    # Resolve only files inside the dedicated job output folder.
    path = (OUTPUTS / Path(job_id).name / Path(filename).name).resolve()
    if path.parent.parent != OUTPUTS.resolve() or not path.is_file():
        raise HTTPException(404, "Media file not found.")
    return FileResponse(path, media_type="video/mp4", filename=path.name)

@app.get("/")
async def root():
    return {"message": "ViralCut AI API. See /docs for API documentation."}
