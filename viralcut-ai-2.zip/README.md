# ViralCut AI

A full-stack long-video-to-short-clips application.

## Architecture
- `backend/`: FastAPI, background jobs, yt-dlp, faster-whisper, Gemini structured output, OpenCV face-aware crop, FFmpeg rendering and ASS captions.
- `frontend/`: Vite + React + TypeScript + Tailwind dashboard.
- Local filesystem storage and in-memory job registry for a single-process local deployment.

## Requirements
- Python 3.11+
- Node.js 20+
- FFmpeg installed and available on PATH
- Gemini API key from Google AI Studio
- Optional: CUDA-enabled PyTorch for faster Whisper transcription

## Run backend
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set GEMINI_API_KEY in .env
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## Run frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Open http://localhost:5173

## Notes
- The backend uses `faster-whisper` with word timestamps. The first run downloads the selected Whisper model.
- YouTube downloads are subject to YouTube's terms, copyright, and local law. Only process videos you own or are authorized to use. Some videos cannot be downloaded due to access restrictions.
- Jobs and metadata are stored in memory and local disk. Restarting the backend loses job status. For a multi-user production deployment, use Redis + Celery/RQ, PostgreSQL, object storage, authentication, quotas, and a reverse proxy.
- For production, run behind HTTPS, restrict upload sizes, scan files, isolate FFmpeg/yt-dlp workers, and enforce per-user storage and processing limits.
